package org.antlr.gunit.swingui.model;

public interface ITestCaseInput {

    public void setScript(String script);
    public String getScript();
}
